﻿namespace ClassLibrary
{
    public class Class1
    {

    }
}
